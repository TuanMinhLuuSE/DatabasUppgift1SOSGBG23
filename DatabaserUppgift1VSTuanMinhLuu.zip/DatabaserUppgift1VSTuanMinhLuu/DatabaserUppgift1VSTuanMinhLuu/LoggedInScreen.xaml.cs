﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;

namespace DatabaserUppgift1VSTuanMinhLuu
{
    /// <summary>
    /// Interaction logic for LoggedInScreen.xaml
    /// </summary>
    public partial class LoggedInScreen : Window
    {
        string connectionString = "server=localhost;database=bankdb;user=root;password=passwordword;";

        List<Cars> carList = new List<Cars>();
        public LoggedInScreen()
        {
            InitializeComponent();
        }

        public void SetListBox()
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM cars";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int carId = reader.GetInt32(0);
                            string carBrand = reader.GetString(1);
                            string carModel = reader.GetString(2);
                            string carType = reader.GetString(3);
                            string carFuelType = reader.GetString(4);
                            int numberOfSeats = reader.GetInt32(5);
                            bool carAvailable = reader.GetBoolean(6);

                            Cars newCar = new Cars(carId, carBrand, carModel, carType, carFuelType, numberOfSeats, carAvailable);
                            carList.Add(newCar);
                        }
                    }
                    connection.Close();
                }
            }


            foreach (Cars cars in carList)
            {
                if(cars.CarAvailable == true)
                {
                    carsToRent.Items.Add(cars.CarBrand + " " + cars.CarModel);
                }
            }
        }

        private void carsToRent_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string selected = carsToRent.SelectedItem.ToString();

            foreach (Cars cars in carList)
            {
                if(selected.Contains(cars.CarModel))
                {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.AppendLine("Brand: " + cars.CarBrand);
                    stringBuilder.AppendLine("Model: " + cars.CarModel);
                    stringBuilder.AppendLine("Type: " + cars.CarType);
                    stringBuilder.AppendLine("Fueltype: " + cars.CarFuelType);
                    stringBuilder.AppendLine("Seats: " + Convert.ToString(cars.CarNumberOfSeats));

                    string result = stringBuilder.ToString();

                    carInfoLabel.Content = result;
                }
            }
        }
    }
}
