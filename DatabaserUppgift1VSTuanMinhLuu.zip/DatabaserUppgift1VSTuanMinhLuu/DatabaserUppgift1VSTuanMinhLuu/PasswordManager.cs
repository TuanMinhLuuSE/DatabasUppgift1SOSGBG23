﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using Org.BouncyCastle.Bcpg.OpenPgp;

namespace DatabaserUppgift1VSTuanMinhLuu
{
    public class PasswordManager
    {
        public string PasswordHasher(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] passwordBytes = Encoding.UTF8.GetBytes(password);
                byte[] hashbytes = sha256.ComputeHash(passwordBytes);

                StringBuilder stringBuilder = new StringBuilder();
                for (int i = 0; i < hashbytes.Length; i++)
                {
                    stringBuilder.Append(hashbytes[i]);
                }

                return stringBuilder.ToString();
            }
        }

        public bool PasswordAuthenticor(string password, string hashedPassword) //NOT USED
        {
            if (PasswordHasher(password) == hashedPassword)
            {
                return true;
            }

            else
            { 
                return false; 
            }
        }
    }
}
