﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatabaserUppgift1VSTuanMinhLuu
{
    public class AccountManager
    {
        string connectionString = "server=localhost;database=bankdb;user=root;password=passwordword;";
        PasswordManager passwordManager = new PasswordManager();
        public bool LoginAuthenticator(string username, string password)
        {
            string hashedPassword = passwordManager.PasswordHasher(password);

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT COUNT(*) FROM rental_account WHERE username = @username AND password = @password";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@username", username);
                    command.Parameters.AddWithValue("@password", hashedPassword);

                    int row = Convert.ToInt32(command.ExecuteScalar());
                    connection.Close();

                    if (row > 0)
                    {
                        return true;
                    }

                    else
                    {
                        return false;
                    }
                }
            }
        }
        public void CreateAccount(string username, string hashedPassword)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string query = "INSERT INTO rental_account VALUES (DEFAULT, @username, @password)";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@username", username);
                    command.Parameters.AddWithValue("@password", hashedPassword);

                    command.ExecuteNonQuery();
                }
                connection.Close();
            }
        }

        public void ChangePassword()
        {

        }
    }
}
